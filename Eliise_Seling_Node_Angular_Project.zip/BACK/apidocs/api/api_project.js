define({
  "name": "MongoMango",
  "version": "1.0.1",
  "description": "Hosting Service for Mongo with API",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-05-20T12:46:12.327Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
